package com.ms.edu.linklist;

public class Node {
	
	private Character data;
	private Node link;
	
	public Node(){};
	public Node(Character data){
		this.data = data;
	}
	public Character getData() {
		return data;
	}
	public void setData(Character data) {
		this.data = data;
	}
	public Node getLink() {
		return link;
	}
	public void setLink(Node link) {
		this.link = link;
	}
	
	
}
