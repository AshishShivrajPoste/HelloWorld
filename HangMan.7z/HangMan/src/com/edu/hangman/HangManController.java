package com.edu.hangman;

public class HangManController {
	
	private static HangManModel hangManModel;
	private static GetGuesses getGuesses;
	private final static int allowedGuess = 6;
	

	public static void main(String[] args) {
		hangManModel = new HangManModel();
		getGuesses = new GetGuesses();
		PayGame();
		
		
	}
	public static void PayGame(){
		int numberofGuessMade = 0;
		Result result;
		do{
			System.out.println("Word to Guess:"+hangManModel.getHiddenWord());
			System.out.println("Guess made so far"+hangManModel.getLettersGuessed());
			System.out.println("Please Make a guess");
			String guess = getGuesses.getGuess();
			char[] character = guess.toCharArray();
			if(guess.equals("") || guess == null){
				System.out.println("Please provide your Input");
				continue;
			}
			hangManModel.addGuess(character[0]);
			if(guess.length() > 1){
				result = hangManModel.checkGuess(guess);
				if(result.equals(Result.CORRECT)){
					System.out.println("YOU WIN CONGRATS!!!");
				}else {
					System.out.println("BAD GUESS");
					numberofGuessMade++;
				}
			}else{
				
				result = hangManModel.getResult(character[0]);
				if(result.equals(Result.CORRECT)){
					System.out.println("GOOD GUESS");
					hangManModel.revealLetter(character[0]);
					if(hangManModel.isWordGuessed()){
						System.out.println("YOU WIN CONGRATS!!!");
						break;
					}
				}else if(result.equals(Result.INCORRECT)){
					System.out.println("BAD GUESS");
					numberofGuessMade++;
				}else if(result.equals(Result.ALREADY_GUESSED)) {
					System.out.println("ALREADY GUESSED CHARACTER");
				}
			}
		}while(numberofGuessMade <= allowedGuess);
		
	}

}
