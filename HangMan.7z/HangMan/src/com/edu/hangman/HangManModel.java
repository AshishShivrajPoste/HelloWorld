package com.edu.hangman;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class HangManModel {

	private List<String> words;
	private String selectedWord;
	private List<Character> hiddenWord;
	private List<Character> lettersGuessed;
	
	public HangManModel(){
		this.hiddenWord = new ArrayList<Character>();
		this.lettersGuessed = new ArrayList<Character>();
		this.words = new ArrayList<String>();
		getListofWords();
		setWord();
		setHiddenWord();
	}
	
	private void getListofWords(){
		words.add("ashish");
		words.add("shashi");
		words.add("bijoy");
		words.add("mangesh");
	}
	
	public void setWord(){
		selectedWord = words.get(new Random().nextInt(words.size()));
	}
	
	public String getWord() {
	        return selectedWord;
	}
	
	private void setHiddenWord() {
        for (char letter: selectedWord.toCharArray()) {
        	hiddenWord.add('-');
        }
    }
	
    public List<Character> getHiddenWord() {
        return hiddenWord;
    }
    private ArrayList<Integer> getIndexesOf(char letter) {
        ArrayList<Integer> instances = new ArrayList<Integer>();
        for (int i = 0; i < selectedWord.length(); i++ ) {
        	if(selectedWord.charAt(i)==letter){
        		 instances.add(i);
        	}
        }
        return instances;
    }
    
    public void revealLetter(char letter) {
        for (int i: getIndexesOf(letter)) {
            hiddenWord.set(i, selectedWord.charAt(i));
        }
    }
    
    public void addGuess(char letter) {
        lettersGuessed.add(letter);
    }
    
    private boolean isGuessed(char letter) {
        return lettersGuessed.indexOf(letter) != -1;
    }
    public Result getResult(char letter) {
        if (!isGuessed(letter)) {
            if (getIndexesOf(letter).size() > 0) {
                return Result.CORRECT;
            }
            else {
            	
                return Result.INCORRECT;
            }
        }
        else {
            return Result.ALREADY_GUESSED;
        }
    }

	public List<Character> getLettersGuessed() {
		return lettersGuessed;
	}

	public void setLettersGuessed(List<Character> lettersGuessed) {
		this.lettersGuessed = lettersGuessed;
	}
	public Result checkGuess(String guess){
		if(selectedWord.equalsIgnoreCase(guess)){
			return Result.CORRECT;
		}else{
			return Result.INCORRECT;
		}
	}
	public Boolean isWordGuessed(){
		if(hiddenWord.contains('-')){
			return false;
		}else {
			return true;
		}
	}
}
