package com.edu.hangman;

import java.util.Scanner;

public class GetGuesses {

	Scanner in;
	
	public GetGuesses() {
		in = new Scanner(System.in);
	}
	
	 public String getGuess()
	 {
		 return in.nextLine();
	 }
	 
}
