package com.edu.hangman;

public enum Result {
	CORRECT , INCORRECT , ALREADY_GUESSED;
}
